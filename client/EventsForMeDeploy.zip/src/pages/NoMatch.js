import React from 'react';

const NoMatch = () => {
  return (
    <div>
      Oops, we couldn't find that page.
    </div>
  );
};

export default NoMatch;