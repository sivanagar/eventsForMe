import styled from "styled-components";

const EventCard = styled.div`
background-color: #9FAB9C;
width: 70%;
text-align: center;
margin: auto;
`;

const Center = styled.div`

`;
export default EventCard;