export const resultSeed = [
  {
    eventTitle: "The Band Event",
    date: "2022-09-30", //TODO from datepicker
    time: "8:00 pm",
    address: "1234 Fake St",
    city: "Santa Monica",
    postalCode: "10000",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ",
    price: "$150",
  },
  {
    eventTitle: "The Band Event 2",
    date: "2022-10-02",
    time: "8:00 pm",
    address: "1234 Fake St",
    city: "Santa Monica",
    postalCode: "10000",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ",
    price: "$150",
  },
  {
    eventTitle: "The Band Event Once again",
    date: "2022-10-05",
    time: "8:00 pm",
    address: "1234 Fake St",
    city: "Santa Monica",
    postalCode: "10000",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ",
    price: "$150",
  },
];
