import React from "react";
import { EventList } from "../../pages/EventList/EventList";
import { Link } from "react-router-dom";

const Dashboard = () => {
  return (
    <div>
      <EventList />
    </div>
  );
};

export default Dashboard;
